from flask import Flask, render_template_string, request, redirect, url_for, flash
from datetime import datetime, timedelta
import json
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'diario_digital_secret_key_2024'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# Crear directorios necesarios
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('data', exist_ok=True)

# Extensiones permitidas
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'mp3', 'wav', 'm4a'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_entries():
    try:
        with open('data/entries.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_entries(entries):
    with open('data/entries.json', 'w', encoding='utf-8') as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)

def get_month_dates(year, month):
    start_date = datetime(year, month, 1)
    if month == 12:
        end_date = datetime(year + 1, 1, 1) - timedelta(days=1)
    else:
        end_date = datetime(year, month + 1, 1) - timedelta(days=1)
    
    dates = []
    current_date = start_date
    while current_date <= end_date:
        dates.append(current_date)
        current_date += timedelta(days=1)
    
    return dates

# Templates HTML completos
BASE_TEMPLATE = '''
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Mi Diario Digital{% endblock %}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
    --primary-color: #3498db;
    --secondary-color: #bb86fc;
    --accent-color: #ff7597;
    --bg-dark: #121212;
    --bg-card: #1e1e1e;
    --bg-surface: #2d2d2d;
    --text-primary: #e0e0e0;
    --text-secondary: #a0a0a0;
    --text-muted: #666666;
    --border-color: #333333;
    --shadow-dark: rgba(0, 0, 0, 0.5);
    --shadow-light: rgba(0, 0, 0, 0.3);
    --success-color: #4caf50;
    --warning-color: #ff9800;
    --danger-color: #f44336;
}

/* Tema Oscuro (por defecto) */
body {
    background-color: var(--bg-dark);
    color: var(--text-primary);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    transition: all 0.3s ease;
}

/* Navbar */
.navbar-dark {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%) !important;
    box-shadow: 0 4px 12px var(--shadow-dark);
}

.navbar-brand {
    font-weight: bold;
    font-size: 1.5rem;
    color: var(--text-primary) !important;
}

/* Calendar Days */
.calendar-day {
    height: 120px;
    border: 1px solid var(--border-color);
    padding: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    background: var(--bg-card);
    overflow: hidden;
    border-radius: 8px;
}

.calendar-day:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px var(--shadow-dark);
    border-color: var(--primary-color);
}

.calendar-day.has-entry {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border-color: var(--secondary-color);
}

.calendar-day.other-month {
    background-color: var(--bg-dark);
    color: var(--text-muted);
    border-color: var(--border-color);
}

.calendar-day.today {
    border: 3px solid var(--accent-color);
    background: var(--bg-surface);
}

.entry-preview {
    font-size: 0.75em;
    opacity: 0.9;
    margin-top: 5px;
    line-height: 1.2;
    color: inherit;
}

/* Navigation Buttons */
.nav-btn {
    background: var(--secondary-color);
    color: var(--bg-dark);
    border: none;
    padding: 10px 20px;
    border-radius: 25px;
    transition: all 0.3s ease;
    font-weight: 600;
}

.nav-btn:hover {
    background: var(--primary-color);
    transform: scale(1.05);
    color: white;
}

/* Forms */
.entry-form {
    background: var(--bg-card);
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 10px 30px var(--shadow-dark);
    border: 1px solid var(--border-color);
}

.file-upload {
    border: 2px dashed var(--border-color);
    border-radius: 10px;
    padding: 20px;
    text-align: center;
    transition: all 0.3s ease;
    background: var(--bg-surface);
    color: var(--text-primary);
}

.file-upload:hover {
    border-color: var(--primary-color);
    background-color: var(--bg-card);
}

/* Report Entries */
.report-entry {
    border-left: 4px solid var(--primary-color);
    padding-left: 15px;
    margin-bottom: 25px;
    background: var(--bg-card);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 8px var(--shadow-light);
    border: 1px solid var(--border-color);
}

/* Cards */
.card {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    color: var(--text-primary);
    box-shadow: 0 2px 8px var(--shadow-light);
}

.card-header {
    background: var(--bg-surface);
    border-bottom: 1px solid var(--border-color);
    color: var(--text-primary);
}

/* Form Elements */
.form-control {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    color: var(--text-primary);
    transition: all 0.3s ease;
}

.form-control:focus {
    background: var(--bg-surface);
    border-color: var(--primary-color);
    color: var(--text-primary);
    box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
}

.form-control::placeholder {
    color: var(--text-muted);
}

.form-label {
    color: var(--text-primary);
    font-weight: 500;
}

.text-muted {
    color: var(--text-muted) !important;
}

/* Admin Panel */
.admin-panel {
    background: linear-gradient(135deg, #7b4397 0%, #dc2430 100%);
    color: white;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 12px var(--shadow-dark);
}

/* Buttons */
.btn-primary {
    background: var(--primary-color);
    border-color: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: #2980b9;
    border-color: #2980b9;
    transform: translateY(-1px);
}

.btn-success {
    background: var(--success-color);
    border-color: var(--success-color);
}

.btn-info {
    background: #17a2b8;
    border-color: #17a2b8;
}

.btn-warning {
    background: var(--warning-color);
    border-color: var(--warning-color);
    color: var(--bg-dark);
}

.btn-danger {
    background: var(--danger-color);
    border-color: var(--danger-color);
}

.btn-outline-primary {
    border-color: var(--primary-color);
    color: var(--primary-color);
}

.btn-outline-primary:hover {
    background-color: var(--primary-color);
    border-color: var(--primary-color);
}

.btn-outline-secondary {
    border-color: var(--text-muted);
    color: var(--text-muted);
}

.btn-outline-secondary:hover {
    background-color: var(--text-muted);
    border-color: var(--text-muted);
}

/* Alerts */
.alert {
    border: 1px solid;
    background: var(--bg-surface);
}

.alert-success {
    background: rgba(76, 175, 80, 0.1);
    border-color: var(--success-color);
    color: #4caf50;
}

.alert-danger {
    background: rgba(244, 67, 54, 0.1);
    border-color: var(--danger-color);
    color: #f44336;
}

.alert-warning {
    background: rgba(255, 152, 0, 0.1);
    border-color: var(--warning-color);
    color: #ff9800;
}

/* Tables */
.table {
    color: var(--text-primary);
    background: var(--bg-card);
}

.table th {
    background: var(--bg-surface);
    border-color: var(--border-color);
    color: var(--text-primary);
}

.table td {
    border-color: var(--border-color);
    background: var(--bg-card);
}

/* Modals */
.modal-content {
    background: var(--bg-card);
    border: 1px solid var(--border-color);
    color: var(--text-primary);
    box-shadow: 0 10px 30px var(--shadow-dark);
}

.modal-header {
    border-bottom: 1px solid var(--border-color);
    background: var(--bg-surface);
}

.modal-footer {
    border-top: 1px solid var(--border-color);
    background: var(--bg-surface);
}

.close {
    color: var(--text-primary);
    text-shadow: 0 1px 0 var(--bg-dark);
}

.close:hover {
    color: var(--accent-color);
}

/* Theme Toggle Button */
.theme-toggle {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 1000;
    background: var(--secondary-color);
    color: var(--bg-dark);
    border: none;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 4px 12px var(--shadow-dark);
    transition: all 0.3s ease;
    font-weight: bold;
}

.theme-toggle:hover {
    transform: scale(1.1) rotate(15deg);
    background: var(--accent-color);
    color: white;
}

/* Audio Player */
audio {
    filter: invert(0.9) hue-rotate(180deg);
}

/* Images */
.img-thumbnail {
    background: var(--bg-surface);
    border: 1px solid var(--border-color);
    border-radius: 8px;
}

/* Empty States */
.empty-day {
    background: var(--bg-dark);
    color: var(--text-muted);
    font-style: italic;
}

/* Print Styles */
.print-only {
    display: none;
}

@media print {
    .no-print {
        display: none !important;
    }
    .print-only {
        display: block !important;
    }
    body {
        font-size: 12px;
        line-height: 1.2;
        background: white !important;
        color: black !important;
    }
    .report-entry {
        page-break-inside: avoid;
        border-left: 2px solid #3498db;
        margin-bottom: 15px;
        padding: 10px;
        background: white !important;
        color: black !important;
    }
    .card {
        background: white !important;
        color: black !important;
        border: 1px solid #ddd !important;
    }
}

/* Responsive Design */
@media (max-width: 768px) {
    .calendar-day {
        height: 80px;
        padding: 4px;
        font-size: 0.8em;
    }
    
    .theme-toggle {
        bottom: 10px;
        right: 10px;
        width: 40px;
        height: 40px;
        font-size: 0.8em;
    }
    
    .entry-form {
        padding: 15px;
    }
    
    .navbar-brand {
        font-size: 1.2rem;
    }
}

/* Smooth Animations */
* {
    transition: background-color 0.3s ease, 
                color 0.3s ease, 
                border-color 0.3s ease,
                box-shadow 0.3s ease,
                transform 0.3s ease;
}

/* Custom Scrollbar */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: var(--bg-dark);
}

::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--primary-color);
}

/* Selection Color */
::selection {
    background: var(--primary-color);
    color: white;
}

::-moz-selection {
    background: var(--primary-color);
    color: white;
}

/* Focus Outline */
*:focus {
    outline: 2px solid var(--primary-color);
    outline-offset: 2px;
}

/* Loading States */
.loading {
    opacity: 0.7;
    pointer-events: none;
}

/* Hover Effects */
.hover-lift:hover {
    transform: translateY(-2px);
}

/* Text Gradients */
.gradient-text {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark no-print" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <a class="navbar-brand" href="{{ url_for('index') }}">
                <i class="fas fa-book"></i> Mi Diario Digital
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ 'danger' if category == 'error' else 'success' }} alert-dismissible fade show no-print">
                        {{ message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        {% block content %}{% endblock %}
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
'''

CALENDAR_TEMPLATE = BASE_TEMPLATE.replace('{% block content %}{% endblock %}', '''
<div class="row mb-4">
    <div class="col-md-8">
        <h1 class="display-4">{{ month_name }} {{ year }}</h1>
    </div>
    <div class="col-md-4 text-end">
        <div class="btn-group">
            <a href="{{ url_for(\'calendar\', year=prev_year, month=prev_month) }}" 
               class="btn nav-btn me-2">
                <i class="fas fa-chevron-left"></i> Anterior
            </a>
            <a href="{{ url_for(\'calendar\', year=next_year, month=next_month) }}" 
               class="btn nav-btn">
                Siguiente <i class="fas fa-chevron-right"></i>
            </a>
        </div>
    </div>
</div>

<!-- Panel de Administración -->
<div class="admin-panel mb-4 no-print">
    <h4><i class="fas fa-cog"></i> Panel de Administración</h4>
    <div class="row mt-3">
        <div class="col-md-6">
            <a href="{{ url_for(\'export_all_html\') }}" class="btn btn-light w-100 mb-2" target="_blank">
                <i class="fas fa-file-pdf"></i> Exportar Todo (HTML)
            </a>
            <small class="text-muted">Exporta todas las entradas a HTML para imprimir</small>
        </div>
        <div class="col-md-6">
            <button type="button" class="btn btn-warning w-100 mb-2" data-bs-toggle="modal" data-bs-target="#clearModal">
                <i class="fas fa-broom"></i> Limpiar Todo
            </button>
            <small class="text-muted">Elimina todas las entradas y archivos</small>
        </div>
    </div>
</div>

<!-- Selector de reporte -->
<div class="row mb-4 no-print">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-file-alt"></i> Ver Reporte por Rango</h5>
                <form id="reportForm" class="row g-3">
                    <div class="col-md-4">
                        <label for="start_date" class="form-label">Desde:</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" required>
                    </div>
                    <div class="col-md-4">
                        <label for="end_date" class="form-label">Hasta:</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" required>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-info w-100">
                            <i class="fas fa-eye"></i> Ver Reporte
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Estadísticas -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-chart-bar"></i> Estadísticas</h5>
                <div class="row text-center">
                    <div class="col-md-3">
                        <h3>{{ total_entries }}</h3>
                        <small class="text-muted">Total Entradas</small>
                    </div>
                    <div class="col-md-3">
                        <h3>{{ total_images }}</h3>
                        <small class="text-muted">Total Imágenes</small>
                    </div>
                    <div class="col-md-3">
                        <h3>{{ total_audio }}</h3>
                        <small class="text-muted">Total Audios</small>
                    </div>
                    <div class="col-md-3">
                        <h3>{{ entries_this_month }}</h3>
                        <small class="text-muted">Este Mes</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Calendario -->
<div class="card">
    <div class="card-body">
        <div class="row text-center fw-bold mb-3" style="background: var(--light-bg); padding: 15px; border-radius: 10px;">
            <div class="col">Lun</div>
            <div class="col">Mar</div>
            <div class="col">Mié</div>
            <div class="col">Jue</div>
            <div class="col">Vie</div>
            <div class="col">Sáb</div>
            <div class="col">Dom</div>
        </div>
        
        {% for week in calendar_data %}
        <div class="row mb-3">
            {% for day in week %}
            <div class="col p-2">
                {% if day %}
                <div class="calendar-day {% if day.has_entry %}has-entry{% endif %} {% if day.date.date() == today.date() %}today{% endif %} rounded"
                     onclick="location.href=\'{{ url_for(\'entry\', date_str=day.date_str) }}\'">
                    <div class="d-flex justify-content-between align-items-start">
                        <strong>{{ day.date.day }}</strong>
                        {% if day.has_entry %}
                        <i class="fas fa-bookmark text-warning"></i>
                        {% endif %}
                    </div>
                    {% if day.entry_preview and day.has_entry %}
                    <div class="entry-preview mt-2">
                        {{ day.entry_preview }}
                    </div>
                    {% endif %}
                </div>
                {% else %}
                <div class="calendar-day other-month rounded"></div>
                {% endif %}
            </div>
            {% endfor %}
        </div>
        {% endfor %}
    </div>
</div>

<!-- Modal para limpiar todo -->
<div class="modal fade" id="clearModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle"></i> Confirmar Limpieza</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="text-danger"><strong>¡ADVERTENCIA!</strong></p>
                <p>Esta acción eliminará:</p>
                <ul>
                    <li>Todas las entradas del diario</li>
                    <li>Todas las imágenes subidas</li>
                    <li>Todos los archivos de audio</li>
                    <li>Todos los datos guardados</li>
                </ul>
                <p><strong>Esta acción no se puede deshacer.</strong></p>
                <p>Escribe <strong>"ELIMINAR TODO"</strong> para confirmar:</p>
                <input type="text" class="form-control" id="confirmText" placeholder="Escribe ELIMINAR TODO aquí">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form method="POST" action="{{ url_for(\'clear_all\') }}" style="display: inline;">
                    <button type="submit" class="btn btn-danger" id="confirmButton" disabled>
                        <i class="fas fa-broom"></i> Limpiar Todo
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById(\'reportForm\').addEventListener(\'submit\', function(e) {
        e.preventDefault();
        const startDate = document.getElementById(\'start_date\').value;
        const endDate = document.getElementById(\'end_date\').value;
        
        if (startDate && endDate) {
            window.location.href = \'{{ url_for(\'view_report\') }}?start_date=\' + startDate + \'&end_date=\' + endDate;
        }
    });

    // Establecer fechas por defecto para reporte (últimos 3 meses)
    const today = new Date();
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(today.getMonth() - 3);
    
    document.getElementById(\'end_date\').valueAsDate = today;
    document.getElementById(\'start_date\').valueAsDate = threeMonthsAgo;

    // Validación para el modal de limpieza
    document.getElementById(\'confirmText\').addEventListener(\'input\', function() {
        const confirmButton = document.getElementById(\'confirmButton\');
        confirmButton.disabled = this.value !== \'ELIMINAR TODO\';
    });
</script>
''').replace('{% block title %}Mi Diario Digital{% endblock %}', 'Calendario - {{ month_name }} {{ year }}')

ENTRY_TEMPLATE = BASE_TEMPLATE.replace('{% block content %}{% endblock %}', '''
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="display-5">
                <i class="fas fa-calendar-day"></i> {{ date_obj.strftime('%A, %d de %B de %Y') }}
            </h1>
            <div>
                <a href="{{ url_for(\'calendar\', year=date_obj.year, month=date_obj.month) }}" 
                   class="btn btn-outline-primary me-2">
                    <i class="fas fa-arrow-left"></i> Volver
                </a>
                <form method="POST" action="{{ url_for(\'delete_entry\', date_str=date_str) }}" 
                      style="display: inline;" onsubmit="return confirm(\'¿Estás seguro de que quieres eliminar esta entrada?\');">
                    <button type="submit" class="btn btn-outline-danger">
                        <i class="fas fa-trash"></i> Eliminar
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <form method="POST" action="{{ url_for(\'save_entry\', date_str=date_str) }}" 
              enctype="multipart/form-data" class="entry-form">
            
            <!-- Texto -->
            <div class="mb-4">
                <label for="text" class="form-label fw-bold">
                    <i class="fas fa-edit"></i> Tu entrada del día:
                </label>
                <textarea class="form-control" id="text" name="text" rows="12" 
                          placeholder="Escribe sobre tu día, pensamientos, actividades...">{{ entry.text or \'\' }}</textarea>
            </div>

            <!-- Imágenes -->
            <div class="mb-4">
                <label class="form-label fw-bold">
                    <i class="fas fa-images"></i> Imágenes:
                </label>
                <div class="file-upload mb-3">
                    <input type="file" class="form-control" name="images" multiple accept="image/*">
                    <small class="text-muted">Puedes seleccionar múltiples imágenes (PNG, JPG, GIF)</small>
                </div>
                
                {% if entry.images %}
                <div class="mt-3">
                    <h6>Imágenes actuales:</h6>
                    <div class="row">
                        {% for image in entry.images %}
                        <div class="col-md-3 mb-2">
                            <img src="{{ url_for(\'static\', filename=\'uploads/\' + image) }}" 
                                 class="img-thumbnail" style="height: 100px; width: 100%; object-fit: cover;">
                            <small class="d-block text-center mt-1">{{ image }}</small>
                        </div>
                        {% endfor %}
                    </div>
                </div>
                {% endif %}
            </div>

            <!-- Audio -->
            <div class="mb-4">
                <label class="form-label fw-bold">
                    <i class="fas fa-microphone"></i> Grabación de audio:
                </label>
                <div class="file-upload mb-3">
                    <input type="file" class="form-control" name="audio" accept="audio/*">
                    <small class="text-muted">Formatos: MP3, WAV, M4A (máx. 16MB)</small>
                </div>
                
                {% if entry.audio %}
                <div class="mt-3">
                    <h6>Audio actual:</h6>
                    <div class="d-flex align-items-center">
                        <audio controls class="flex-grow-1 me-3">
                            <source src="{{ url_for(\'static\', filename=\'uploads/\' + entry.audio) }}">
                            Tu navegador no soporta el elemento de audio.
                        </audio>
                        <small class="text-muted">{{ entry.audio }}</small>
                    </div>
                </div>
                {% endif %}
            </div>

            <!-- Botones -->
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <button type="submit" class="btn btn-success btn-lg">
                    <i class="fas fa-save"></i> Guardar Entrada
                </button>
            </div>
        </form>
    </div>
</div>
''').replace('{% block title %}Mi Diario Digital{% endblock %}', 'Entrada - {{ date_str }}')

REPORT_TEMPLATE = BASE_TEMPLATE.replace('{% block content %}{% endblock %}', '''
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="display-5">
                <i class="fas fa-file-alt"></i> Reporte de Diario
            </h1>
            <div class="no-print">
                <a href="{{ url_for(\'index\') }}" class="btn btn-outline-primary me-2">
                    <i class="fas fa-arrow-left"></i> Volver al Calendario
                </a>
                <button onclick="window.print()" class="btn btn-success me-2">
                    <i class="fas fa-print"></i> Imprimir/Guardar PDF
                </button>
                <a href="{{ url_for(\'export_html\', start_date=start_date.strftime(\'%Y-%m-%d\'), end_date=end_date.strftime(\'%Y-%m-%d\')) }}" 
                   class="btn btn-info" target="_blank">
                    <i class="fas fa-file-export"></i> Exportar HTML
                </a>
            </div>
        </div>
        
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Período: {{ start_date.strftime(\'%d/%m/%Y\') }} - {{ end_date.strftime(\'%d/%m/%Y\') }}</h5>
                <p class="card-text">Total de entradas: {{ entries|length }}</p>
                <div class="print-only">
                    <p><strong>Documento generado el:</strong> {{ datetime.now().strftime(\'%d/%m/%Y %H:%M\') }}</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        {% for date_str, entry_data in entries.items()|sort %}
        <div class="report-entry">
            <h3 class="text-primary">{{ datetime.strptime(date_str, \'%Y-%m-%d\').strftime(\'%A, %d de %B de %Y\') }}</h3>
            
            {% if entry_data.text %}
            <div class="mb-3">
                <strong>Texto:</strong>
                <p class="mt-2" style="white-space: pre-wrap;">{{ entry_data.text }}</p>
            </div>
            {% endif %}
            
            {% if entry_data.images %}
            <div class="mb-3">
                <strong>Imágenes ({{ entry_data.images|length }}):</strong>
                <div class="row mt-2">
                    {% for image in entry_data.images %}
                    <div class="col-md-2 mb-2">
                        <img src="{{ url_for(\'static\', filename=\'uploads/\' + image) }}" 
                             class="img-thumbnail w-100">
                    </div>
                    {% endfor %}
                </div>
            </div>
            {% endif %}
            
            {% if entry_data.audio %}
            <div class="mb-3">
                <strong>Audio:</strong>
                <div class="mt-2">
                    <audio controls class="no-print">
                        <source src="{{ url_for(\'static\', filename=\'uploads/\' + entry_data.audio) }}">
                        Tu navegador no soporta el elemento de audio.
                    </audio>
                    <p class="print-only"><em>Audio adjunto: {{ entry_data.audio }}</em></p>
                </div>
            </div>
            {% endif %}
            
            <small class="text-muted">
                Última modificación: {{ entry_data.last_modified[:16].replace(\'T\', \' \') }}
            </small>
        </div>
        {% endfor %}
    </div>
</div>
''').replace('{% block title %}Mi Diario Digital{% endblock %}', 'Reporte - {{ start_date.strftime(\'%d/%m/%Y\') }} a {{ end_date.strftime(\'%d/%m/%Y\') }}')

EXPORT_TEMPLATE = '''
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #3498db;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .entry {
            border-left: 4px solid #3498db;
            padding-left: 15px;
            margin-bottom: 25px;
            page-break-inside: avoid;
        }
        .entry-date {
            color: #2c3e50;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .entry-text {
            white-space: pre-wrap;
            margin-bottom: 15px;
        }
        .stats {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }
        @media print {
            body {
                font-size: 12px;
                margin: 10px;
            }
            .entry {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>{{ title }}</h1>
        {% if subtitle %}
        <h2>{{ subtitle }}</h2>
        {% endif %}
        <div class="stats">
            <p><strong>Estadísticas:</strong> {{ total_entries }} entradas, {{ total_images }} imágenes, {{ total_audio }} audios</p>
            <p><strong>Período:</strong> {{ start_date.strftime('%d/%m/%Y') }} - {{ end_date.strftime('%d/%m/%Y') }}</p>
            <p><strong>Generado el:</strong> {{ generated_date }}</p>
        </div>
    </div>

    {% for date_str, entry_data in entries.items()|sort %}
    <div class="entry">
        <div class="entry-date">{{ datetime.strptime(date_str, '%Y-%m-%d').strftime('%A, %d de %B de %Y') }}</div>
        
        {% if entry_data.text %}
        <div class="entry-text">{{ entry_data.text }}</div>
        {% endif %}
        
        {% if entry_data.images %}
        <p><strong>Imágenes adjuntas:</strong> {{ entry_data.images|length }}</p>
        {% endif %}
        
        {% if entry_data.audio %}
        <p><strong>Audio adjunto:</strong> Sí</p>
        {% endif %}
        
        <p><em>Última modificación: {{ entry_data.last_modified[:16].replace('T', ' ') }}</em></p>
    </div>
    {% endfor %}

    <div class="footer">
        <p>Documento generado por Mi Diario Digital - {{ generated_date }}</p>
    </div>

    <script>
        // Auto-print cuando se abre la página
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>
'''

@app.route('/')
def index():
    today = datetime.now()
    return redirect(url_for('calendar', year=today.year, month=today.month))

@app.route('/calendar/<int:year>/<int:month>')
def calendar(year, month):
    if month < 1 or month > 12:
        today = datetime.now()
        return redirect(url_for('calendar', year=today.year, month=today.month))
    
    prev_month = month - 1
    prev_year = year
    if prev_month == 0:
        prev_month = 12
        prev_year = year - 1
    
    next_month = month + 1
    next_year = year
    if next_month == 13:
        next_month = 1
        next_year = year + 1
    
    dates = get_month_dates(year, month)
    entries = load_entries()
    
    # Calcular estadísticas
    total_entries = len(entries)
    total_images = sum(len(entry.get('images', [])) for entry in entries.values())
    total_audio = sum(1 for entry in entries.values() if entry.get('audio'))
    
    # Entradas este mes
    current_month = datetime.now().month
    current_year = datetime.now().year
    entries_this_month = sum(1 for date_str in entries.keys() 
                           if datetime.strptime(date_str, '%Y-%m-%d').month == current_month 
                           and datetime.strptime(date_str, '%Y-%m-%d').year == current_year)
    
    calendar_data = []
    week = []
    
    first_day = dates[0]
    for _ in range(first_day.weekday()):
        week.append(None)
    
    for date in dates:
        date_str = date.strftime('%Y-%m-%d')
        entry = entries.get(date_str, {})
        has_entry = bool(entry.get('text') or entry.get('images') or entry.get('audio'))
        
        week.append({
            'date': date,
            'date_str': date_str,
            'has_entry': has_entry,
            'entry_preview': entry.get('text', '')[:100] + '...' if entry.get('text') else ''
        })
        
        if len(week) == 7:
            calendar_data.append(week)
            week = []
    
    if week:
        while len(week) < 7:
            week.append(None)
        calendar_data.append(week)
    
    month_names = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
    
    return render_template_string(CALENDAR_TEMPLATE,
                         year=year,
                         month=month,
                         month_name=month_names[month],
                         calendar_data=calendar_data,
                         prev_year=prev_year,
                         prev_month=prev_month,
                         next_year=next_year,
                         next_month=next_month,
                         today=datetime.now(),
                         total_entries=total_entries,
                         total_images=total_images,
                         total_audio=total_audio,
                         entries_this_month=entries_this_month)

@app.route('/entry/<date_str>')
def entry(date_str):
    entries = load_entries()
    entry_data = entries.get(date_str, {})
    
    try:
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        flash('Fecha inválida', 'error')
        return redirect(url_for('index'))
    
    return render_template_string(ENTRY_TEMPLATE,
                         date_str=date_str,
                         date_obj=date_obj,
                         entry=entry_data)

@app.route('/save_entry/<date_str>', methods=['POST'])
def save_entry(date_str):
    entries = load_entries()
    
    try:
        datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        flash('Fecha inválida', 'error')
        return redirect(url_for('index'))
    
    text = request.form.get('text', '')
    
    images = []
    if 'images' in request.files:
        for file in request.files.getlist('images'):
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{date_str}_{datetime.now().strftime('%H%M%S')}_{file.filename}")
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                images.append(filename)
    
    audio = None
    if 'audio' in request.files:
        file = request.files['audio']
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(f"{date_str}_audio_{datetime.now().strftime('%H%M%S')}_{file.filename}")
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            audio = filename
    
    entries[date_str] = {
        'text': text,
        'images': images,
        'audio': audio,
        'last_modified': datetime.now().isoformat()
    }
    
    save_entries(entries)
    flash('Entrada guardada exitosamente', 'success')
    return redirect(url_for('entry', date_str=date_str))

@app.route('/view_report')
def view_report():
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    
    if not start_date_str or not end_date_str:
        flash('Debe especificar fechas de inicio y fin', 'error')
        return redirect(url_for('index'))
    
    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    except ValueError:
        flash('Formato de fecha inválido', 'error')
        return redirect(url_for('index'))
    
    entries = load_entries()
    
    filtered_entries = {}
    current_date = start_date
    while current_date <= end_date:
        date_str = current_date.strftime('%Y-%m-%d')
        if date_str in entries:
            filtered_entries[date_str] = entries[date_str]
        current_date += timedelta(days=1)
    
    if not filtered_entries:
        flash('No hay entradas en el rango de fechas seleccionado', 'warning')
        return redirect(url_for('index'))
    
    return render_template_string(REPORT_TEMPLATE,
                         start_date=start_date,
                         end_date=end_date,
                         entries=filtered_entries,
                         datetime=datetime)

@app.route('/export_html')
def export_html():
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    
    if not start_date_str or not end_date_str:
        flash('Debe especificar fechas de inicio y fin', 'error')
        return redirect(url_for('index'))
    
    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    except ValueError:
        flash('Formato de fecha inválido', 'error')
        return redirect(url_for('index'))
    
    entries = load_entries()
    
    filtered_entries = {}
    current_date = start_date
    while current_date <= end_date:
        date_str = current_date.strftime('%Y-%m-%d')
        if date_str in entries:
            filtered_entries[date_str] = entries[date_str]
        current_date += timedelta(days=1)
    
    if not filtered_entries:
        flash('No hay entradas en el rango de fechas seleccionado', 'warning')
        return redirect(url_for('index'))
    
    total_entries = len(filtered_entries)
    total_images = sum(len(entry.get('images', [])) for entry in filtered_entries.values())
    total_audio = sum(1 for entry in filtered_entries.values() if entry.get('audio'))
    
    return render_template_string(EXPORT_TEMPLATE,
                         title=f"Reporte de Diario - {start_date.strftime('%d/%m/%Y')} a {end_date.strftime('%d/%m/%Y')}",
                         subtitle="Exportación para impresión",
                         entries=filtered_entries,
                         start_date=start_date,
                         end_date=end_date,
                         total_entries=total_entries,
                         total_images=total_images,
                         total_audio=total_audio,
                         generated_date=datetime.now().strftime('%d/%m/%Y %H:%M'),
                         datetime=datetime)

@app.route('/export_all_html')
def export_all_html():
    entries = load_entries()
    
    if not entries:
        flash('No hay entradas para exportar', 'warning')
        return redirect(url_for('index'))
    
    # Obtener fechas mínima y máxima
    dates = [datetime.strptime(date_str, '%Y-%m-%d') for date_str in entries.keys()]
    start_date = min(dates)
    end_date = max(dates)
    
    total_entries = len(entries)
    total_images = sum(len(entry.get('images', [])) for entry in entries.values())
    total_audio = sum(1 for entry in entries.values() if entry.get('audio'))
    
    return render_template_string(EXPORT_TEMPLATE,
                         title="Reporte Completo de Diario",
                         subtitle="Todas las entradas - Exportación completa",
                         entries=entries,
                         start_date=start_date,
                         end_date=end_date,
                         total_entries=total_entries,
                         total_images=total_images,
                         total_audio=total_audio,
                         generated_date=datetime.now().strftime('%d/%m/%Y %H:%M'),
                         datetime=datetime)

@app.route('/clear_all', methods=['POST'])
def clear_all():
    entries = load_entries()
    
    if not entries:
        flash('No hay datos para limpiar', 'warning')
        return redirect(url_for('index'))
    
    # Eliminar todos los archivos de imágenes y audio
    for entry_data in entries.values():
        for image in entry_data.get('images', []):
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image)
            if os.path.exists(image_path):
                os.remove(image_path)
        
        if entry_data.get('audio'):
            audio_path = os.path.join(app.config['UPLOAD_FOLDER'], entry_data['audio'])
            if os.path.exists(audio_path):
                os.remove(audio_path)
    
    # Limpiar el archivo de entradas
    save_entries({})
    
    flash('¡Todos los datos han sido eliminados exitosamente!', 'success')
    return redirect(url_for('index'))

@app.route('/delete_entry/<date_str>', methods=['POST'])
def delete_entry(date_str):
    entries = load_entries()
    
    if date_str in entries:
        # Eliminar archivos asociados
        entry = entries[date_str]
        for image in entry.get('images', []):
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image)
            if os.path.exists(image_path):
                os.remove(image_path)
        
        if entry.get('audio'):
            audio_path = os.path.join(app.config['UPLOAD_FOLDER'], entry['audio'])
            if os.path.exists(audio_path):
                os.remove(audio_path)
        
        # Eliminar entrada
        del entries[date_str]
        save_entries(entries)
        flash('Entrada eliminada exitosamente', 'success')
    else:
        flash('Entrada no encontrada', 'error')
    
    return redirect(url_for('calendar', year=datetime.now().year, month=datetime.now().month))

if __name__ == '__main__':
    print("Iniciando Diario Digital...")
    print("URL: http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)